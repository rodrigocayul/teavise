<h1>Ejemplo Array</h1>
<?php 

// Definir variable miarray y cargar el array con datos
$miarray = array('uno','dos','tres');

//Iterar el arreglo
foreach($miarray as $fila){
	
	echo $fila;
	echo "<hr />";
}
?>

<h1>Ejemplo Array Asociativo</h1>
<?php
// Definir variable miarrayAsociativo que se refiere indice => valor 
$miarrayAsociativo = array( '1' => 'uno' ,'2' => 'dos' ,'3' => 'tres');

//Iterar array asociativo
foreach($miarrayAsociativo as $indice => $valor){
	
	echo $indice." - ".$valor;
	echo "<hr />";
	
}
?>

<h1>Ejemplo Array Asociativo Aplicado en Desarrollo</h1>
<h4>Mis Sitios Favoritos</h4>
<?php
// Definir variable miarrayAsociativo que se refiere indice => valor 
$miarrayAsociativo = array( 'http://www.google.com' 	=> 'Google' ,
							'http://www.youtube.com' 	=> 'Youtube' ,
							'http://www.aprendeer.com' 	=> 'Aprendeer',
					);
//Iterar Array Asociativo
foreach($miarrayAsociativo as $indice => $valor){
?>	
	<a href="<?php echo $indice; ?>"><?php echo $valor; ?></a> <br />
<?php	
}
?>